from enum import Enum


class Response(Enum):
    """
    Enum de respuesta del usuario
    """

    YES = 1
    NO = 0
